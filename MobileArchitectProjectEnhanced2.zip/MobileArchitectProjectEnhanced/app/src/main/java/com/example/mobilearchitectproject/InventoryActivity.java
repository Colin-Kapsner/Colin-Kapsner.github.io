package com.example.mobilearchitectproject;

import android.content.Intent;
import android.os.Bundle;
import android.Manifest;
import android.content.pm.PackageManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    private enum SortOption {
        NAME_ASC,
        NAME_DESC,
        QTY_ASC,
        QTY_DESC
    }

    private DatabaseHelper databaseHelper;
    private InventoryAdapter adapter;
    private EditText editSearch;
    private SortOption currentSortOption = SortOption.NAME_ASC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        Toolbar toolbar = findViewById(R.id.inventoryToolbar);
        setSupportActionBar(toolbar);

        // InventoryActivity gets its own access to the database
        databaseHelper = new DatabaseHelper(this);

        // Ask for SMS permission when the inventory screen opens
        requestSmsPermission();

        EditText editItemName = findViewById(R.id.editItemName);
        EditText editItemQuantity = findViewById(R.id.editItemQuantity);
        Button buttonAddItem = findViewById(R.id.buttonAddItem);
        // this is the container holding the fields that appear when Add Item is pressed
        LinearLayout containerInputFields = findViewById(R.id.containerInputFields);
        Button buttonConfirmAdd = findViewById(R.id.buttonConfirmAdd);

        // Setup RecyclerView
        RecyclerView recyclerView = findViewById(R.id.recyclerInventory);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        
        adapter = new InventoryAdapter(new ArrayList<>(), new InventoryAdapter.OnItemInteractionListener() {
            @Override
            public void onDecrease(InventoryItem item) {
                int newQuantity = item.getQuantity() - 1;
                if (newQuantity < 0) newQuantity = 0;
                databaseHelper.updateQuantity(item.getId(), newQuantity);
                if (newQuantity == 0) {
                    Toast.makeText(InventoryActivity.this, item.getName() + " is out of stock", Toast.LENGTH_SHORT).show();
                }
                loadInventoryGrid();
            }

            @Override
            public void onIncrease(InventoryItem item) {
                databaseHelper.updateQuantity(item.getId(), item.getQuantity() + 1);
                loadInventoryGrid();
            }

            @Override
            public void onRemove(InventoryItem item) {
                databaseHelper.deleteItem(item.getId());
                loadInventoryGrid();
            }
        });
        recyclerView.setAdapter(adapter);

        editSearch = findViewById(R.id.editSearch);
        editSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                loadInventoryGrid();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Display the inventory as soon as this screen opens
        loadInventoryGrid();

        // Toggle visibility of input fields
        buttonAddItem.setOnClickListener(view -> {
            if (containerInputFields.getVisibility() == View.GONE) {
                containerInputFields.setVisibility(View.VISIBLE);
                buttonAddItem.setText("Cancel");
            } else {
                //clear the text in the fields and go back to the add button.
                editItemName.setText("");
                editItemQuantity.setText("");
                containerInputFields.setVisibility(View.GONE);
                buttonAddItem.setText("Add Item");
            }
        });

        // Confirm Add a new inventory item
        buttonConfirmAdd.setOnClickListener(view -> {
            String itemName = editItemName.getText().toString().trim();
            String quantityText = editItemQuantity.getText().toString().trim();

            if (itemName.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(
                        this,
                        "Enter item name and quantity",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            // Improved input validation for quantity field
            int quantity;

            try {
                quantity = Integer.parseInt(quantityText);
            } catch (NumberFormatException e) {
                Toast.makeText(
                        this,
                        "Quantity must be a whole number",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            if (quantity < 0) {
                Toast.makeText(
                        this,
                        "Quantity cannot be negative",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            databaseHelper.addItem(itemName, quantity);

            editItemName.setText("");
            editItemQuantity.setText("");
            containerInputFields.setVisibility(View.GONE);
            buttonAddItem.setText("Add Item");

            loadInventoryGrid();
        });
    }

    // Checks whether SMS permission is already allowed.
// If not, it asks the user for permission.
    private void requestSmsPermission() {

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    100);
        }
    }

    private void loadInventoryGrid() {
        // DatabaseHelper gives us completed InventoryItem objects
        ArrayList<InventoryItem> inventoryItems = databaseHelper.getAllItems();

        // 1. Filter using InventoryAlgorithms
        String query = (editSearch != null) ? editSearch.getText().toString() : "";
        ArrayList<InventoryItem> displayList = InventoryAlgorithms.searchByName(inventoryItems, query);

        // 2. Sort using InventoryAlgorithms
        switch (currentSortOption) {
            case NAME_DESC:
                displayList = InventoryAlgorithms.sortByNameDesc(displayList);
                break;
            case QTY_ASC:
                displayList = InventoryAlgorithms.sortByQuantityAsc(displayList);
                break;
            case QTY_DESC:
                displayList = InventoryAlgorithms.sortByQuantityDesc(displayList);
                break;
            case NAME_ASC:
            default:
                displayList = InventoryAlgorithms.sortByNameAsc(displayList);
                break;
        }

        adapter.updateData(displayList);
    }

    // These two methods are for the menu functionality
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.inventory_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.sort_name_asc) {
            currentSortOption = SortOption.NAME_ASC;
            loadInventoryGrid();
            return true;
        } else if (itemId == R.id.sort_name_desc) {
            currentSortOption = SortOption.NAME_DESC;
            loadInventoryGrid();
            return true;
        } else if (itemId == R.id.sort_qty_asc) {
            currentSortOption = SortOption.QTY_ASC;
            loadInventoryGrid();
            return true;
        } else if (itemId == R.id.sort_qty_desc) {
            currentSortOption = SortOption.QTY_DESC;
            loadInventoryGrid();
            return true;
        } else if (itemId == R.id.action_logout) {
            Intent intent =
                    new Intent(InventoryActivity.this, MainActivity.class);

            // Clear navigation history so Back cannot return to inventory
            intent.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
            );

            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
