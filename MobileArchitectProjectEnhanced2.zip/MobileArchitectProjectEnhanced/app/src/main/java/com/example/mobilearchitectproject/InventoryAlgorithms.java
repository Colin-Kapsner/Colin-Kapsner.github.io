package com.example.mobilearchitectproject;

import java.util.ArrayList;

public class InventoryAlgorithms {

    // --- SEARCH ALGORITHMS ---

    /**
     * Filters inventory items by matching item name with the search query (case-insensitive).
     */
    public static ArrayList<InventoryItem> searchByName(
            ArrayList<InventoryItem> items, String query) {

        ArrayList<InventoryItem> result = new ArrayList<>();
        if (items == null) {
            return result;
        }

        if (query == null || query.trim().isEmpty()) {
            result.addAll(items);
            return result;
        }

        String lowerQuery = query.trim().toLowerCase();
        for (InventoryItem item : items) {
            if (item != null && item.getName() != null &&
                    item.getName().toLowerCase().contains(lowerQuery)) {
                result.add(item);
            }
        }
        return result;
    }

    // --- SORT ALGORITHMS ---

    /**
     * Sorts inventory items by Name ascending (A-Z) using Merge Sort.
     */
    public static ArrayList<InventoryItem> sortByNameAsc(
            ArrayList<InventoryItem> items) {
        return mergeSortByName(items);
    }

    public static ArrayList<InventoryItem> mergeSortByName(
            ArrayList<InventoryItem> items) {

        // already sorted
        if (items == null || items.size() <= 1) {
            return items;
        }

        int middle = items.size() / 2;

        ArrayList<InventoryItem> left =
                new ArrayList<>(items.subList(0, middle));

        ArrayList<InventoryItem> right =
                new ArrayList<>(items.subList(middle, items.size()));

        left = mergeSortByName(left);
        right = mergeSortByName(right);

        return mergeByName(left, right);
    }

    private static ArrayList<InventoryItem> mergeByName(
            ArrayList<InventoryItem> left,
            ArrayList<InventoryItem> right) {

        ArrayList<InventoryItem> result = new ArrayList<>();

        int leftIndex = 0;
        int rightIndex = 0;

        while (leftIndex < left.size() && rightIndex < right.size()) {
            InventoryItem leftItem = left.get(leftIndex);
            InventoryItem rightItem = right.get(rightIndex);

            String leftName = leftItem.getName() != null ? leftItem.getName() : "";
            String rightName = rightItem.getName() != null ? rightItem.getName() : "";

            if (leftName.compareToIgnoreCase(rightName) <= 0) {
                result.add(leftItem);
                leftIndex++;
            } else {
                result.add(rightItem);
                rightIndex++;
            }
        }

        while (leftIndex < left.size()) {
            result.add(left.get(leftIndex));
            leftIndex++;
        }

        while (rightIndex < right.size()) {
            result.add(right.get(rightIndex));
            rightIndex++;
        }

        return result;
    }

    /**
     * Sorts inventory items by Name descending (Z-A) using Merge Sort.
     */
    public static ArrayList<InventoryItem> sortByNameDesc(
            ArrayList<InventoryItem> items) {

        // already sorted
        if (items == null || items.size() <= 1) {
            return items;
        }

        int middle = items.size() / 2;

        ArrayList<InventoryItem> left =
                new ArrayList<>(items.subList(0, middle));

        ArrayList<InventoryItem> right =
                new ArrayList<>(items.subList(middle, items.size()));

        left = sortByNameDesc(left);
        right = sortByNameDesc(right);

        return mergeByNameDesc(left, right);
    }

    private static ArrayList<InventoryItem> mergeByNameDesc(
            ArrayList<InventoryItem> left,
            ArrayList<InventoryItem> right) {

        ArrayList<InventoryItem> result = new ArrayList<>();

        int leftIndex = 0;
        int rightIndex = 0;

        while (leftIndex < left.size() && rightIndex < right.size()) {
            InventoryItem leftItem = left.get(leftIndex);
            InventoryItem rightItem = right.get(rightIndex);

            String leftName = leftItem.getName() != null ? leftItem.getName() : "";
            String rightName = rightItem.getName() != null ? rightItem.getName() : "";

            if (leftName.compareToIgnoreCase(rightName) >= 0) {
                result.add(leftItem);
                leftIndex++;
            } else {
                result.add(rightItem);
                rightIndex++;
            }
        }

        while (leftIndex < left.size()) {
            result.add(left.get(leftIndex));
            leftIndex++;
        }

        while (rightIndex < right.size()) {
            result.add(right.get(rightIndex));
            rightIndex++;
        }

        return result;
    }

    /**
     * Sorts inventory items by Quantity ascending (Low-High) using Merge Sort.
     */
    public static ArrayList<InventoryItem> sortByQuantityAsc(
            ArrayList<InventoryItem> items) {

        if (items == null || items.size() <= 1) {
            return items;
        }

        int middle = items.size() / 2;

        ArrayList<InventoryItem> left =
                new ArrayList<>(items.subList(0, middle));

        ArrayList<InventoryItem> right =
                new ArrayList<>(items.subList(middle, items.size()));

        left = sortByQuantityAsc(left);
        right = sortByQuantityAsc(right);

        return mergeByQuantityAsc(left, right);
    }

    private static ArrayList<InventoryItem> mergeByQuantityAsc(
            ArrayList<InventoryItem> left,
            ArrayList<InventoryItem> right) {

        ArrayList<InventoryItem> result = new ArrayList<>();

        int leftIndex = 0;
        int rightIndex = 0;

        while (leftIndex < left.size() && rightIndex < right.size()) {
            InventoryItem leftItem = left.get(leftIndex);
            InventoryItem rightItem = right.get(rightIndex);

            if (leftItem.getQuantity() <= rightItem.getQuantity()) {
                result.add(leftItem);
                leftIndex++;
            } else {
                result.add(rightItem);
                rightIndex++;
            }
        }

        while (leftIndex < left.size()) {
            result.add(left.get(leftIndex));
            leftIndex++;
        }

        while (rightIndex < right.size()) {
            result.add(right.get(rightIndex));
            rightIndex++;
        }

        return result;
    }

    /**
     * Sorts inventory items by Quantity descending (High-Low) using Merge Sort.
     */
    public static ArrayList<InventoryItem> sortByQuantityDesc(
            ArrayList<InventoryItem> items) {

        if (items == null || items.size() <= 1) {
            return items;
        }

        int middle = items.size() / 2;

        ArrayList<InventoryItem> left =
                new ArrayList<>(items.subList(0, middle));

        ArrayList<InventoryItem> right =
                new ArrayList<>(items.subList(middle, items.size()));

        left = sortByQuantityDesc(left);
        right = sortByQuantityDesc(right);

        return mergeByQuantityDesc(left, right);
    }

    private static ArrayList<InventoryItem> mergeByQuantityDesc(
            ArrayList<InventoryItem> left,
            ArrayList<InventoryItem> right) {

        ArrayList<InventoryItem> result = new ArrayList<>();

        int leftIndex = 0;
        int rightIndex = 0;

        while (leftIndex < left.size() && rightIndex < right.size()) {
            InventoryItem leftItem = left.get(leftIndex);
            InventoryItem rightItem = right.get(rightIndex);

            if (leftItem.getQuantity() >= rightItem.getQuantity()) {
                result.add(leftItem);
                leftIndex++;
            } else {
                result.add(rightItem);
                rightIndex++;
            }
        }

        while (leftIndex < left.size()) {
            result.add(left.get(leftIndex));
            leftIndex++;
        }

        while (rightIndex < right.size()) {
            result.add(right.get(rightIndex));
            rightIndex++;
        }

        return result;
    }
}
