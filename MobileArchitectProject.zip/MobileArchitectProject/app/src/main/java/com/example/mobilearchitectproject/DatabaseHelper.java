package com.example.mobilearchitectproject;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

public class DatabaseHelper extends SQLiteOpenHelper {

    // name of the database
    private static final String DATABASE_NAME = "InventoryApp.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        // Calls the parent SQLiteOpenHelper constructor and creates
        // or opens the database file.
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL command used to create the table that stores user accounts
        String createUsersTable = "CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE, " +
                "password TEXT)";

        // SQL command used to create the table that stores inventory items
        String createInventoryTable = "CREATE TABLE inventory (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "itemName TEXT, " +
                "quantity INTEGER)";

        // executes both commands
        db.execSQL(createUsersTable);
        db.execSQL(createInventoryTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // Deletes the old tables if the database version changes
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS inventory");

        // Recreates the database using the newest structure
        onCreate(db);
    }

    // Adds a new user to the users table
    public boolean addUser(String username, String password) {

        SQLiteDatabase db = this.getWritableDatabase();

        // Holds the values that will be inserted into the table
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        // insert() returns -1 if something goes wrong
        long result = db.insert("users", null, values);

        return result != -1;
    }

    // Checks whether a username and password match a record in the database
    public boolean checkUser(String username, String password) {

        SQLiteDatabase db = this.getReadableDatabase();

        // ? placeholders prevent SQL injection and let us safely
        // insert the username and password into the query
        Cursor cursor = db.rawQuery(
                "SELECT * FROM users WHERE username=? AND password=?",
                new String[]{username, password});

        boolean exists = cursor.getCount() > 0;

        cursor.close();

        return exists;
    }

    // Adds a new inventory item to the inventory table
    public boolean addItem(String itemName, int quantity) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("itemName", itemName);
        values.put("quantity", quantity);

        long result = db.insert("inventory", null, values);

        return result != -1;
    }

    // Returns all inventory items from the database
    public Cursor getAllItems() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM inventory",
                null);
    }

    // Deletes one inventory item based on its database ID
    public boolean deleteItem(int id) {

        SQLiteDatabase db = this.getWritableDatabase();

        // Deletes the row where the id matches the item selected
        int result = db.delete("inventory", "id=?", new String[]{String.valueOf(id)});

        // If result is greater than 0, something was deleted
        return result > 0;
    }

    // Updates the quantity for one inventory item
    public boolean updateQuantity(int id, int newQuantity) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("quantity", newQuantity);

        int result = db.update("inventory", values, "id=?", new String[]{String.valueOf(id)});

        return result > 0;
    }
}