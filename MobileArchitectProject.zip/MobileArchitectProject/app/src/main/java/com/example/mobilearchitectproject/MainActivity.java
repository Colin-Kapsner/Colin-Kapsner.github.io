package com.example.mobilearchitectproject;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.database.Cursor;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    // These variables let Java interact with the text fields and buttons
    EditText editUsername, editPassword;
    Button buttonLogin, buttonCreateAccount;

    // This gives MainActivity access to the SQLite database code
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Connects Java variables to the UI elements in activity_login.xml
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Creates the database helper so we can add and check users
        databaseHelper = new DatabaseHelper(this);

        buttonCreateAccount.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            // Prevents empty accounts from being created
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter a username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean created = databaseHelper.addUser(username, password);

            if (created) {
                Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Account already exists", Toast.LENGTH_SHORT).show();
            }
        });

        buttonLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            // Checks the database for a matching username and password
            boolean validLogin = databaseHelper.checkUser(username, password);

            if (validLogin) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();

                // Opens the inventory screen after the user logs in
                setContentView(R.layout.activity_inventory);
                requestSmsPermission();
                loadInventoryGrid();

                EditText editItemName = findViewById(R.id.editItemName);
                EditText editItemQuantity = findViewById(R.id.editItemQuantity);
                Button buttonAddItem = findViewById(R.id.buttonAddItem);

                // Add item button
                buttonAddItem.setOnClickListener(view -> {
                    String itemName = editItemName.getText().toString().trim();
                    String quantityText = editItemQuantity.getText().toString().trim();

                    if (itemName.isEmpty() || quantityText.isEmpty()) {
                        Toast.makeText(this, "Enter item name and quantity", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int quantity = Integer.parseInt(quantityText);

                    databaseHelper.addItem(itemName, quantity);

                    editItemName.setText("");
                    editItemQuantity.setText("");

                    loadInventoryGrid();
                });
            } else {
                Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Loads inventory items from the database and shows them in the grid
    private void loadInventoryGrid() {

        LinearLayout gridInventory = findViewById(R.id.gridInventory);

        // Clears the grid so old items do not duplicate
        gridInventory.removeAllViews();

        // Gets all inventory rows from the database
        Cursor cursor = databaseHelper.getAllItems();

        while (cursor.moveToNext()) {

            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow("itemName"));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));

            // Create one horizontal row
            LinearLayout row = new LinearLayout(this);
            row.setPadding(0, 20, 0, 20);
            row.setOrientation(LinearLayout.HORIZONTAL);


            // Create the text that displays the item information
            TextView itemView = new TextView(this);
            itemView.setText(
                    itemName + "\nQuantity: " + quantity);

            // Create the remove button
            Button removeButton = new Button(this);
            removeButton.setText("Remove");

            // Delete this specific item
            removeButton.setOnClickListener(view -> {
                databaseHelper.deleteItem(id);
                loadInventoryGrid();
            });

            // Decrease item count button
            Button decreaseButton = new Button(this);
            decreaseButton.setText("-");

            decreaseButton.setOnClickListener(view -> {
                int newQuantity = quantity - 1;

                if (newQuantity < 0) {
                    newQuantity = 0;
                }

                databaseHelper.updateQuantity(id, newQuantity);
                if (newQuantity == 0) {
                    Toast.makeText(this, itemName + " is out of stock", Toast.LENGTH_SHORT).show();
                }
                loadInventoryGrid();
            });

            // Increase item count button
            Button increaseButton = new Button(this);
            increaseButton.setText("+");

            increaseButton.setOnClickListener(view -> {
                databaseHelper.updateQuantity(id, quantity + 1);
                loadInventoryGrid();
            });

            // Add the text and button to the row
            row.addView(itemView);
            row.addView(decreaseButton);
            row.addView(increaseButton);
            row.addView(removeButton);

            // Add the completed row to the inventory layout
            gridInventory.addView(row);
        }

        cursor.close();
    }

    // Checks whether SMS permission is already allowed.
// If not, it asks the user for permission.
    private void requestSmsPermission() {

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    100);
        }
    }
}