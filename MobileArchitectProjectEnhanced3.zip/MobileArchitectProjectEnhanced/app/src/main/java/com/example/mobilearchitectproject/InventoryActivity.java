package com.example.mobilearchitectproject;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

// Main inventory management activity displaying user inventory items
public class InventoryActivity extends AppCompatActivity {

    // Available sorting options for the inventory list
    private enum SortOption {
        NAME_ASC,
        NAME_DESC,
        QTY_ASC,
        QTY_DESC
    }

    private DatabaseHelper databaseHelper;
    private InventoryAdapter adapter;
    private EditText editSearch;
    private SortOption currentSortOption = SortOption.NAME_ASC;
    private int currentUserId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initialize top action bar toolbar
        Toolbar toolbar = findViewById(R.id.inventoryToolbar);
        setSupportActionBar(toolbar);

        // Retrieve logged-in user ID passed from MainActivity
        currentUserId = getIntent().getIntExtra("USER_ID", -1);

        // Initialize database helper instance
        databaseHelper = new DatabaseHelper(this);

        // Request SMS permission if not already granted
        requestSmsPermission();

        EditText editItemName = findViewById(R.id.editItemName);
        EditText editItemQuantity = findViewById(R.id.editItemQuantity);
        Button buttonAddItem = findViewById(R.id.buttonAddItem);
        LinearLayout containerInputFields = findViewById(R.id.containerInputFields);
        Button buttonConfirmAdd = findViewById(R.id.buttonConfirmAdd);

        // Setup RecyclerView layout manager and adapter
        RecyclerView recyclerView = findViewById(R.id.recyclerInventory);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Configure interaction listener callbacks for adapter items (+, -, and Remove)
        adapter = new InventoryAdapter(new ArrayList<>(), new InventoryAdapter.OnItemInteractionListener() {
            @Override
            public void onDecrease(InventoryItem item) {
                // Decrement quantity without dropping below zero
                int newQuantity = Math.max(0, item.getQuantity() - 1);
                databaseHelper.updateQuantity(item.getId(), newQuantity);

                if (newQuantity == 0) {
                    Toast.makeText(InventoryActivity.this, item.getName() + " is out of stock", Toast.LENGTH_SHORT).show();
                }
                loadInventoryGrid();
            }

            @Override
            public void onIncrease(InventoryItem item) {
                // Increment item quantity in database
                databaseHelper.updateQuantity(item.getId(), item.getQuantity() + 1);
                loadInventoryGrid();
            }

            @Override
            public void onRemove(InventoryItem item) {
                // Delete selected item from database
                databaseHelper.deleteItem(item.getId());
                loadInventoryGrid();
            }
        });
        recyclerView.setAdapter(adapter);

        // Live text filter for inventory search bar
        editSearch = findViewById(R.id.editSearch);
        editSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Filter and update display list dynamically as user types
                loadInventoryGrid();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Initial inventory load
        loadInventoryGrid();

        // Toggle visibility of item entry input fields
        buttonAddItem.setOnClickListener(view -> {
            if (containerInputFields.getVisibility() == View.GONE) {
                containerInputFields.setVisibility(View.VISIBLE);
                buttonAddItem.setText(R.string.cancel);
            } else {
                // Clear input fields and hide form
                editItemName.setText("");
                editItemQuantity.setText("");
                containerInputFields.setVisibility(View.GONE);
                buttonAddItem.setText(R.string.add_item);
            }
        });

        // Validate and insert a new inventory item
        buttonConfirmAdd.setOnClickListener(view -> {
            String itemName = editItemName.getText().toString().trim();
            String quantityText = editItemQuantity.getText().toString().trim();

            if (itemName.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(this, "Enter item name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            // Input validation for non-negative integer quantity
            int quantity;
            try {
                quantity = Integer.parseInt(quantityText);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Quantity must be a whole number", Toast.LENGTH_SHORT).show();
                return;
            }

            if (quantity < 0) {
                Toast.makeText(this, "Quantity cannot be negative", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save item linked to current logged-in user
            databaseHelper.addItem(itemName, quantity, currentUserId);

            // Reset form fields
            editItemName.setText("");
            editItemQuantity.setText("");
            containerInputFields.setVisibility(View.GONE);
            buttonAddItem.setText(R.string.add_item);

            loadInventoryGrid();
        });
    }

    // Requests SEND_SMS runtime permission if not already granted
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    100);
        }
    }

    // Loads, filters, sorts, and updates the RecyclerView display list
    private void loadInventoryGrid() {
        // Fetch inventory items specific to the logged-in user
        ArrayList<InventoryItem> inventoryItems = (currentUserId != -1) ?
                databaseHelper.getItemsForUser(currentUserId) :
                databaseHelper.getAllItems();

        // 1. Filter items by search query string
        String query = (editSearch != null) ? editSearch.getText().toString() : "";
        ArrayList<InventoryItem> displayList = InventoryAlgorithms.searchByName(inventoryItems, query);

        // 2. Sort filtered items according to selected sort option
        switch (currentSortOption) {
            case NAME_DESC:
                displayList = InventoryAlgorithms.sortByNameDesc(displayList);
                break;
            case QTY_ASC:
                displayList = InventoryAlgorithms.sortByQuantityAsc(displayList);
                break;
            case QTY_DESC:
                displayList = InventoryAlgorithms.sortByQuantityDesc(displayList);
                break;
            case NAME_ASC:
            default:
                displayList = InventoryAlgorithms.sortByNameAsc(displayList);
                break;
        }

        // Update adapter dataset and refresh view
        adapter.updateData(displayList);
    }

    // Inflates the overflow options menu (R.menu.inventory_menu)
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.inventory_menu, menu);
        return true;
    }

    // Handles user selections in the options menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.sort_name_asc) {
            currentSortOption = SortOption.NAME_ASC;
            loadInventoryGrid();
            return true;
        } else if (itemId == R.id.sort_name_desc) {
            currentSortOption = SortOption.NAME_DESC;
            loadInventoryGrid();
            return true;
        } else if (itemId == R.id.sort_qty_asc) {
            currentSortOption = SortOption.QTY_ASC;
            loadInventoryGrid();
            return true;
        } else if (itemId == R.id.sort_qty_desc) {
            currentSortOption = SortOption.QTY_DESC;
            loadInventoryGrid();
            return true;
        } else if (itemId == R.id.action_clear_inventory) {
            // Prompt confirmation dialog before wiping inventory list
            new AlertDialog.Builder(this)
                    .setTitle("Clear Inventory")
                    .setMessage("Are you sure you want to clear your entire inventory list? This action cannot be undone.")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        if (currentUserId != -1) {
                            databaseHelper.clearInventoryForUser(currentUserId);
                        } else {
                            databaseHelper.clearAllItems();
                        }
                        loadInventoryGrid();
                        Toast.makeText(InventoryActivity.this, "Inventory cleared", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("No", null)
                    .show();
            return true;
        } else if (itemId == R.id.action_logout) {
            // Prompt confirmation dialog before logging out
            new AlertDialog.Builder(this)
                    .setTitle("Logout")
                    .setMessage("Are you sure you want to log out?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        Intent intent = new Intent(InventoryActivity.this, MainActivity.class);

                        // Clear navigation activity stack so Back button cannot return to inventory
                        intent.setFlags(
                                Intent.FLAG_ACTIVITY_NEW_TASK |
                                        Intent.FLAG_ACTIVITY_CLEAR_TASK
                        );

                        startActivity(intent);
                    })
                    .setNegativeButton("No", null)
                    .show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
