package com.example.mobilearchitectproject;

public class InventoryItem {

    // Information that belongs to one inventory item
    private int id;
    private String name;
    private int quantity;
    private int userId;

    // Constructor used to create an InventoryItem object
    public InventoryItem(int id, String name, int quantity) {
        this(id, name, quantity, -1);
    }

    public InventoryItem(int id, String name, int quantity, int userId) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.userId = userId;
    }

    // Getters allow other classes to read the item's information
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getUserId() {
        return userId;
    }

    // Allows the quantity to be changed
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
