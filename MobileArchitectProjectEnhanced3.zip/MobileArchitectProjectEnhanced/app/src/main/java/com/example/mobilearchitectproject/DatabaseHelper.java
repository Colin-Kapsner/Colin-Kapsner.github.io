package com.example.mobilearchitectproject;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;
import java.util.ArrayList;

// DatabaseHelper manages SQLite database creation, schema upgrades, and CRUD operations
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name and current version number
    private static final String DATABASE_NAME = "InventoryApp.db";
    private static final int DATABASE_VERSION = 3;

    public DatabaseHelper(Context context) {
        // Calls SQLiteOpenHelper constructor to create or open the database file
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Configures SQLite database options (enables foreign key constraint support)
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    // Called when the database is created for the first time
    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL query to create users table storing account credentials
        String createUsersTable = "CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE, " +
                "password TEXT)";

        // SQL query to create inventory table linked to users via foreign key (user_id)
        String createInventoryTable = "CREATE TABLE inventory (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "itemName TEXT, " +
                "quantity INTEGER, " +
                "user_id INTEGER, " +
                "FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)";

        // SQL query to create history tracking table for item quantity changes
        String createInventoryHistoryTable = "CREATE TABLE inventory_history (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "item_id INTEGER, " +
                "old_quantity INTEGER, " +
                "new_quantity INTEGER, " +
                "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP, " +
                "FOREIGN KEY(item_id) REFERENCES inventory(id) ON DELETE CASCADE)";

        // Execute table creation statements
        db.execSQL(createUsersTable);
        db.execSQL(createInventoryTable);
        db.execSQL(createInventoryHistoryTable);
    }

    // Handles database schema migrations gracefully across versions without losing existing user data
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // Upgrade v1 to v2: Create history log table
            db.execSQL("CREATE TABLE IF NOT EXISTS inventory_history (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "item_id INTEGER, " +
                    "old_quantity INTEGER, " +
                    "new_quantity INTEGER, " +
                    "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP, " +
                    "FOREIGN KEY(item_id) REFERENCES inventory(id) ON DELETE CASCADE)");
        }
        if (oldVersion < 3) {
            // Upgrade v2 to v3: Add user ownership column to inventory table
            db.execSQL("ALTER TABLE inventory ADD COLUMN user_id INTEGER DEFAULT -1");
        }
    }

    // Inserts a new user account into the users table
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        // Returns true if insertion was successful (row id != -1)
        long result = db.insert("users", null, values);
        return result != -1;
    }

    // Checks whether a username and password match a record in the users table
    public boolean checkUser(String username, String password) {
        return getUserId(username, password) != -1;
    }

    // Queries the database for user credentials and returns the user's ID, or -1 if invalid
    public int getUserId(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        int userId = -1;

        // Use parameterized query placeholders (?) to prevent SQL injection
        Cursor cursor = db.rawQuery(
                "SELECT id FROM users WHERE username=? AND password=?",
                new String[]{username, password});

        if (cursor.moveToFirst()) {
            userId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
        }

        cursor.close();
        return userId;
    }

    // Adds an inventory item without specifying a user (defaults owner user_id to -1)
    public boolean addItem(String itemName, int quantity) {
        return addItem(itemName, quantity, -1);
    }

    // Adds a new inventory item connected to a specific user ID
    public boolean addItem(String itemName, int quantity, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("itemName", itemName);
        values.put("quantity", quantity);
        values.put("user_id", userId);

        long result = db.insert("inventory", null, values);
        return result != -1;
    }

    // Retrieves only the inventory items created by a specific user
    public ArrayList<InventoryItem> getItemsForUser(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<InventoryItem> inventoryItems = new ArrayList<>();

        // Parameterized query filtering inventory rows by user_id
        Cursor cursor = db.rawQuery(
                "SELECT * FROM inventory WHERE user_id=?",
                new String[]{String.valueOf(userId)});

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String name = cursor.getString(cursor.getColumnIndexOrThrow("itemName"));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
            int uId = cursor.getInt(cursor.getColumnIndexOrThrow("user_id"));

            inventoryItems.add(new InventoryItem(id, name, quantity, uId));
        }

        cursor.close();
        return inventoryItems;
    }

    // Retrieves all inventory items across all users in the database
    public ArrayList<InventoryItem> getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<InventoryItem> inventoryItems = new ArrayList<>();

        Cursor cursor = db.rawQuery("SELECT * FROM inventory", null);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String name = cursor.getString(cursor.getColumnIndexOrThrow("itemName"));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
            int uId = cursor.getColumnIndex("user_id") != -1 ?
                    cursor.getInt(cursor.getColumnIndexOrThrow("user_id")) : -1;

            inventoryItems.add(new InventoryItem(id, name, quantity, uId));
        }

        cursor.close();
        return inventoryItems;
    }

    // Deletes a single inventory item by its database row ID
    public boolean deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("inventory", "id=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    // Deletes all inventory items belonging to a specific user
    public boolean clearInventoryForUser(int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result;
        if (userId != -1) {
            result = db.delete("inventory", "user_id=?", new String[]{String.valueOf(userId)});
        } else {
            result = db.delete("inventory", null, null);
        }
        return result > 0;
    }

    // Deletes all inventory items from the database
    public boolean clearAllItems() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("inventory", null, null) > 0;
    }

    // Updates the quantity of an item and automatically logs the change in inventory_history
    public boolean updateQuantity(int id, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Query the current quantity prior to update to track quantity delta
        int oldQuantity = 0;
        Cursor cursor = db.rawQuery("SELECT quantity FROM inventory WHERE id=?", new String[]{String.valueOf(id)});
        if (cursor.moveToFirst()) {
            oldQuantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
        }
        cursor.close();

        ContentValues values = new ContentValues();
        values.put("quantity", newQuantity);

        // Perform quantity update
        int result = db.update("inventory", values, "id=?", new String[]{String.valueOf(id)});

        // Automatically log change in history table if update succeeded
        if (result > 0) {
            recordHistory(id, oldQuantity, newQuantity);
        }

        return result > 0;
    }

    // Inserts a log entry into inventory_history recording old vs new quantity changes
    public boolean recordHistory(int itemId, int oldQuantity, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("item_id", itemId);
        values.put("old_quantity", oldQuantity);
        values.put("new_quantity", newQuantity);

        long result = db.insert("inventory_history", null, values);
        return result != -1;
    }

    // Retrieves history change logs for a specific item, ordered by newest first
    public ArrayList<InventoryHistoryRecord> getHistoryForItem(int itemId) {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<InventoryHistoryRecord> historyList = new ArrayList<>();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM inventory_history WHERE item_id=? ORDER BY id DESC",
                new String[]{String.valueOf(itemId)});

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            int oldQty = cursor.getInt(cursor.getColumnIndexOrThrow("old_quantity"));
            int newQty = cursor.getInt(cursor.getColumnIndexOrThrow("new_quantity"));
            String timestamp = cursor.getString(cursor.getColumnIndexOrThrow("timestamp"));

            historyList.add(new InventoryHistoryRecord(id, itemId, oldQty, newQty, timestamp));
        }

        cursor.close();
        return historyList;
    }
}
