package com.example.mobilearchitectproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

// Handles user authentication including login and account creation
public class MainActivity extends AppCompatActivity {

    // UI elements for login and registration
    private EditText editUsername, editPassword;

    // Database helper for user authentication checks
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Connect Java variables to the UI layout elements
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Initialize SQLite database helper
        databaseHelper = new DatabaseHelper(this);

        // Handle user account registration
        buttonCreateAccount.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            // Validate that neither field is empty
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter a username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Attempt to insert the new user into the database
            boolean created = databaseHelper.addUser(username, password);

            if (created) {
                Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Account already exists", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle user authentication and navigation to inventory screen
        buttonLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            // Query database for matching user credentials and retrieve user ID
            int userId = databaseHelper.getUserId(username, password);

            if (userId != -1) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();

                // Pass the user ID to InventoryActivity so only user-owned items display
                Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
                intent.putExtra("USER_ID", userId);
                intent.putExtra("USERNAME", username);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
