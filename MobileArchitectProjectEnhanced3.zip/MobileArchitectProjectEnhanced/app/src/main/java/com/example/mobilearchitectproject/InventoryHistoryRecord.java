package com.example.mobilearchitectproject;

// Data model representing a single inventory modification log entry
public class InventoryHistoryRecord {

    private final int id;
    private final int itemId;
    private final int oldQuantity;
    private final int newQuantity;
    private final String timestamp;

    // Constructor to initialize an inventory history record
    public InventoryHistoryRecord(int id, int itemId, int oldQuantity, int newQuantity, String timestamp) {
        this.id = id;
        this.itemId = itemId;
        this.oldQuantity = oldQuantity;
        this.newQuantity = newQuantity;
        this.timestamp = timestamp;
    }

    // Getters for accessing record fields
    public int getId() {
        return id;
    }

    public int getItemId() {
        return itemId;
    }

    public int getOldQuantity() {
        return oldQuantity;
    }

    public int getNewQuantity() {
        return newQuantity;
    }

    public String getTimestamp() {
        return timestamp;
    }
}
