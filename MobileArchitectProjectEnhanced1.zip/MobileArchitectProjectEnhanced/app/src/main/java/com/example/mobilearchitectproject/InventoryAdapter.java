package com.example.mobilearchitectproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

/**
 * InventoryAdapter manages the display of inventory items in a RecyclerView.
 * It binds the data from a list of InventoryItem objects to the UI elements defined in item_inventory.xml.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private ArrayList<InventoryItem> items;
    private OnItemInteractionListener listener;

    /**
     * Interface to handle interactions with individual inventory items.
     * This allows the Activity to handle the actual database logic.
     */
    public interface OnItemInteractionListener {
        void onDecrease(InventoryItem item);
        void onIncrease(InventoryItem item);
        void onRemove(InventoryItem item);
    }

    public InventoryAdapter(ArrayList<InventoryItem> items, OnItemInteractionListener listener) {
        this.items = items;
        this.listener = listener;
    }

    /**
     * Updates the data set and refreshes the RecyclerView display.
     */
    public void updateData(ArrayList<InventoryItem> newItems) {
        this.items = newItems;
        notifyDataSetChanged();
    }

    /**
     * onCreateViewHolder is called when the RecyclerView needs a new ViewHolder instance.
     * It inflates the row layout (item_inventory.xml).
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    /**
     * onBindViewHolder connects the data of an InventoryItem to the UI views in a ViewHolder.
     * This is called as the user scrolls through the list.
     */
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item = items.get(position);
        holder.textItemName.setText(item.getName());
        holder.textItemQuantity.setText("Quantity: " + item.getQuantity());

        // Set up click listeners that trigger the callback interface
        holder.buttonDecrease.setOnClickListener(v -> listener.onDecrease(item));
        holder.buttonIncrease.setOnClickListener(v -> listener.onIncrease(item));
        holder.buttonRemove.setOnClickListener(v -> listener.onRemove(item));
    }

    /**
     * Returns the total number of items in the list.
     */
    @Override
    public int getItemCount() {
        return items.size();
    }

    /**
     * ViewHolder acts as a cache for the UI components of a single row.
     * This prevents frequent calls to findViewById, improving scrolling performance.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textItemName, textItemQuantity;
        Button buttonDecrease, buttonIncrease, buttonRemove;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // Locate each UI element within the row layout
            textItemName = itemView.findViewById(R.id.textItemName);
            textItemQuantity = itemView.findViewById(R.id.textItemQuantity);
            buttonDecrease = itemView.findViewById(R.id.buttonDecrease);
            buttonIncrease = itemView.findViewById(R.id.buttonIncrease);
            buttonRemove = itemView.findViewById(R.id.buttonRemove);
        }
    }
}
