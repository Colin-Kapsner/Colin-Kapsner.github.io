package com.example.mobilearchitectproject;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.database.Cursor;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {
    // These variables let Java interact with the text fields and buttons
    EditText editUsername, editPassword;
    Button buttonLogin, buttonCreateAccount;

    // This gives MainActivity access to the SQLite database code
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Connects Java variables to the UI elements in activity_login.xml
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Creates the database helper so we can add and check users
        databaseHelper = new DatabaseHelper(this);

        buttonCreateAccount.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            // Prevents empty accounts from being created
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter a username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean created = databaseHelper.addUser(username, password);

            if (created) {
                Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Account already exists", Toast.LENGTH_SHORT).show();
            }
        });

        buttonLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            // Checks the database for a matching username and password
            boolean validLogin = databaseHelper.checkUser(username, password);

            if (validLogin) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Loads inventory items from the database and shows them in the grid
}

