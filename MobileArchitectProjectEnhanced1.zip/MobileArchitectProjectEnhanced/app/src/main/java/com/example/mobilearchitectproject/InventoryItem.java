package com.example.mobilearchitectproject;

public class InventoryItem {

    // Information that belongs to one inventory item
    private int id;
    private String name;
    private int quantity;

    // Constructor used to create an InventoryItem object
    public InventoryItem(int id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    // Getters allow other classes to read the item's information
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    // Allows the quantity to be changed
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
